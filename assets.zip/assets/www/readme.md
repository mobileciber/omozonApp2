# Backbone.js + jQuery Mobile #

A sample application that shows how to combine [Backbone.js](http://documentcloud.github.com/backbone/) (for the application structure and “routing”) and [jQuery Mobile](http://jquerymobile.com/) (for its styles and widgets).

This sample application is documented [here]( http://coenraets.org/blog/2012/03/using-backbone-js-with-jquery-mobile)

Links:

http://backbonetutorials.com/
https://github.com/fiznool/backbone.basicauth
http://clintberry.com/2012/backbone-js-apps-authentication-tutorial/ (bad)
https://devblog.supportbee.com/2013/02/12/jquery-mobile-backbone-backbone/ => https://code.google.com/p/crypto-js/

http://blog.bigbinary.com/2011/08/18/understanding-bind-and-bindall-in-backbone.html
http://de.wikipedia.org/wiki/First-Class-Funktion

Session
https://github.com/AlexChittock/JQuery-Session-Plugin
http://stackoverflow.com/questions/11580172/session-handling-in-jquery
https://gist.github.com/davemo/3875274
https://github.com/mikeedwards/Backbone.DOMStorage
https://github.com/makesites/backbone-session